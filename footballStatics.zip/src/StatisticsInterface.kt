interface StatisticsInterface {
    fun addStatistic()
    fun statistics()
    fun deleteStatistics()
    fun searchStatics()
    fun editStatics()

}
